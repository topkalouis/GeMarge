<?php defined('page') or die('VOUS N\'AVEZ PAS DROIT A CETTE PAGE');?>
<title>Configuration - GeMarge ::: Logiciel D'émargement</title>
<!--sub-heard-part-->
									  <div class="sub-heard-part">
									   <ol class="breadcrumb m-b-0">
											<li><a href="index.html">Configuration</a></li>
											<li class="active">Configuration principale</li>
										</ol>
									   </div>
								  <!--//sub-heard-part-->
									<div class="graph-visual tables-main">
											<h2 class="inner-tittle">Configuration</h2>
												<div class="graph">
														 <div class="block-page">
<!--DEBUT CONTENU-->
											<a href="?/AjoutMatieres/" class="btn btn-primary">Ajout de Matieres</a>
										    <a href="?/AjoutFiliere/" class="btn btn-success">Ajout de Filières</a>
											<a href="?/AjoutModule/" class="btn btn-warning">Ajout de Module</a>
											<a href="?/AnneeScolaire/" class="btn btn-primary">Année Scolaire</a>
                                            <a href="?/ChangerAnnSco/" class="btn btn-success">Changer Année Scolaire & Module</a>

<!--FIN CONTENU-->
																
                                                                </div>
										        </div>
<div id="txtHint3"></div>											
										</div>
										<!--//graph-visual-->