
<?php 
// Modifier le 2016-06-21
$idann_sco=1; 
$ann_sco="2016-2017";
$idmodule="1";
$module="1er Module";
?>